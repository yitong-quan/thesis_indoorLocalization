/*
 * DWM1000.mem.h
 *
 *  Created on: 03.05.2016
 *      Author: Patrick Fehrenbach
 */

#ifndef DWM1000_MEM_H_
#define DWM1000_MEM_H_

extern volatile dwt_local_data_t DWM1000local ; 	// Static local device data

#endif /* DWM1000_MEM_H_ */



