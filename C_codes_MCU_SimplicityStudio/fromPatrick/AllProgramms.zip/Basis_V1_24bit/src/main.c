/**************************************************************************//**
 * @file
 * @brief tableFinder-baseStation
 * @version
 ******************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "em_usart.h"
#include "em_device.h"
#include "em_system.h"

#include "config.h"
#include "HWinit_loc.h"
#if MODE == NORMAL
#include "w5100.h"
#include "socket.h"
#include "dhcp.h"
#include "ethernet.h"
#endif
#include "CC1101.h"
#include "CC1190.h"
#include "RADIO.h"
#include "RADIO_CONFIG.h"
#include "RFPACKETHELPER.h"
#include "UART.h"
#include "CRC.h"
#include "RTC.h"
#include "EEPROM_handler.h"
#include "ANTENNA.h"
#include "WorkModes.h"
#include "TestModes.h"

/*******************************************************************************
 ***************************   GLOBAL VARIABLES   ******************************
 ******************************************************************************/

/* PA table settings, see config.h */
uint8_t paTableWakeUp[8] = PA_TABLE_LOW_POWER;
uint8_t paTableData[8] = PA_FSK;

//#define PORTE 	4
/*#define SPI_MOSI 	10
 #define SPI_MISO 	11
 #define SPI_CLK 	12
 #define SPI_CS		13*/
//#define COM_PORT gpioPortC
//#define TX_PIN   0
//#define RX_PIN   1
#define LEDPort gpioPortB
//#define red 13
#define green 14
//#define blue 11

//#define UART_receive_LENGTH 100

//char UART_receive[UART_receive_LENGTH];

/*Global variables*/
uint8_t MAC[] = MACADRESS
uint8_t Gateway[4] = { 0 };
uint8_t SubnetMask[4] = { 0 };
uint8_t IPAddress[4] = { 0 };
uint8_t buffer[256] = { 0 };
//uint8_t CC1101_receive[256] = { 0 };
uint16_t port = 1;
uint8_t usedhcp = 0;

#if REVISION == BASE_REV_2
// Default set antenna 1
bool antUse = ANT1;
#endif
// echo on uart
int echo = 0;
bool error = false;
bool uartError = false;
int uartLength = 0;
int datLength = 0;

// BASIS VARIABLES
uint32_t MY_BASE_ID = 0x0001;  	// ID of this Basis

// SYSTEM SETTINGS
//#define CC1101_SPI_BAUDRATE	5000000ULL

// SYSTEM VARIABLES
struct radio_transfer xfer;  // Radio Transfer Handler
char string_buffer[256] = { 0 }; // UART String Buffer

/* AES VARIABLES */
uint8_t AES_decryption_key[16];  						// AES Decryption Key
uint8_t AES_encryption_key[] = AES_ENCRYPTION_KEY; // AES Encryption Key 128 bit
uint8_t AES_decryption_public_key[16];  				// AES Decryption Key
uint8_t AES_encryption_public_key[] = AES_ENCRYPTION_PUBLIC_KEY; // AES Encryption Key 128 bit
const uint8_t AES_initVector[] = AES_INIT_VECTOR; // Initialization vector used during CBC

// INTERRUPT ROUTINES DECLARATION
void TIMER1_IRQHandler(void);
void GPIO_EVEN_IRQHandler(void);
void GPIO_ODD_IRQHandler(void);

// Function declaration
void sendPacket(uint32_t wakeupid, uint8_t option, uint8_t *data, uint8_t len);
void listenForResponse(uint8_t *buffer, uint32_t wakeupid, uint8_t msgType,
		uint8_t *len, int8_t *ccrssi, uint32_t *identifier_addr);
bool checkACK(uint32_t wakeupid);
uint8_t Encrypt_AES128CBC(uint8_t *buffer, uint8_t len, const uint8_t *key,
		const uint8_t *iv);
uint8_t Decrypt_AES128CBC(uint8_t *buffer, const uint8_t *key,
		const uint8_t *iv);
void arraycpy(uint8_t *dest, uint8_t *src, int start, int len);
int stringToIP(uint8_t *buffer, uint8_t *ip);
void getID(uint8_t *buffer, uint32_t *id, uint8_t *comlen, uint8_t offset,
		bool isHEX);
uint8_t getBufferLength(uint8_t *buffer);
uint8_t getIdLength(uint8_t *buffer, uint8_t start);
uint8_t getIdSpace(uint8_t *buffer, uint8_t start);
void printMSG(char *buffer, int length);
void testComponents(void);

/**************************************************************************//**
 * @brief  Main function
 *****************************************************************************/
int main(void) {
	/* Chip errata */
	CHIP_Init();

	// Use RC Oscillator (HF)
	CMU_OscillatorEnable(cmuOsc_HFRCO, true, false);
	CMU_HFRCOBandSet(cmuHFRCOBand_21MHz);
	CMU_ClockDivSet(cmuClock_HFPER, cmuClkDiv_1);
	CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);

	// Use Crystal Osc (LF)
	CMU_OscillatorEnable(cmuOsc_LFXO, true, true);
	CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_LFXO);
	CMU_ClockSelectSet(cmuClock_LFB, cmuSelect_LFXO);
	CMU_ClockEnable(cmuClock_CORELE, true);
	CMU_ClockEnable(cmuClock_RTC, true);

	EEPROM_init();

	//==============================================================================
	// enter_DefaultMode_from_RESET
	//==============================================================================
	enter_DefaultMode_from_RESET();

	// RTC init
	RTC_init(1000);  // Init RTC, set to 1s
	TIMER_init(TIMER0, cmuClock_TIMER0, TIMER0_IRQn);
	TIMER_init_us(TIMER2, cmuClock_TIMER2, TIMER2_IRQn);

	SysTick_Delay_init();

	/* Initialize CC1101 RF Module */
	//cc1101_spi_init(CC1101_SPI_BAUDRATE);
	//cc1101_change_config_to(CC1101_WAKEUP_CONFIG, PLUS_12dBm);
	NVIC_EnableIRQ(GPIO_EVEN_IRQn); /* Enable interrupt. */
	NVIC_EnableIRQ(GPIO_ODD_IRQn);
	radio_init(&xfer, TIMER1, cmuClock_TIMER1, TIMER1_IRQn);

	// Reads data from Flash and writes it into local variable
	EEPROM_read_and_store_into(&MY_BASE_ID, AES_encryption_key, IPAddress,
			SubnetMask, Gateway, &port, &usedhcp);

	//Use a testmode
	#if MODE != NORMAL
		TESTMODE_enter(&xfer);
	#else
	// TODO: Add BASE_ID to DHCP name
	Dhcp_setID(&MY_BASE_ID);

	// Calculate (once) decryption key from the original key
	AES_DecryptKey128(AES_decryption_key, AES_encryption_key);
	AES_DecryptKey128(AES_decryption_public_key, AES_encryption_public_key);

#if REVISION == BASE_REV_2
	//switch to receive mode
	BASE_ANTENNA_switch(SKY_DEST_PE, PE_DEST_SKY, antUse);
#endif
	cc1190_receive();

	// Test all leds
	testComponents();

	// Status of the ethernet initialization
	int etherstatus = 0;

	// Config interrupt from W5100
	//GPIO_IntConfig(W5100IntPort, W5100IntPin, false, true, true);
	//GPIO_IntEnable(1 << W5100IntPin);

	// Print the Basis ID serial
	sprintf(string_buffer, "Basis ID: 0x%X (%d) \r\n", (int) MY_BASE_ID,
			(int) MY_BASE_ID);
	UART_WriteString(string_buffer, strlen(string_buffer));
	memset(string_buffer, '\0', sizeof(string_buffer));

	RTC_delay_ms(1500);

	if (usedhcp == 1) {
		// Init ethernet connection with DHCP use
		etherstatus = Ethernet_dhcp_init(MAC, IPAddress, Gateway, SubnetMask);
	} else {
		// Init ethernet connection without DHCP use
		Ethernet_init(MAC, IPAddress, Gateway, SubnetMask);
		etherstatus = 1;
	}

	if (etherstatus) {
		// Start TCP server
		Ethernet_start(1, port);
		if (usedhcp == 1) {
			strcpy(string_buffer, "Network settings got from DHCP\r\n");
			UART_WriteString(string_buffer, strlen(string_buffer));
			memset(string_buffer, '\0', sizeof(string_buffer));
		}
		sprintf(string_buffer, "TCP-Server started on Port %d\r\n", port);
		UART_WriteString(string_buffer, strlen(string_buffer));
		memset(string_buffer, '\0', sizeof(string_buffer));
		sprintf(string_buffer, "IP-Adress: %d.%d.%d.%d\r\n", IPAddress[0],
				IPAddress[1], IPAddress[2], IPAddress[3]);
		UART_WriteString(string_buffer, strlen(string_buffer));
		memset(string_buffer, '\0', sizeof(string_buffer));
		sprintf(string_buffer, "Subnet Mask: %d.%d.%d.%d\r\n", SubnetMask[0],
				SubnetMask[1], SubnetMask[2], SubnetMask[3]);
		UART_WriteString(string_buffer, strlen(string_buffer));
		memset(string_buffer, '\0', sizeof(string_buffer));
		sprintf(string_buffer, "Gateway: %d.%d.%d.%d\r\n", Gateway[0],
				Gateway[1], Gateway[2], Gateway[3]);
		UART_WriteString(string_buffer, strlen(string_buffer));
	} else {
		strcpy(string_buffer, "DHCP Error!\r\n");
		UART_WriteString(string_buffer, strlen(string_buffer));
	}


	UART_WriteString("Ready\r\n", strlen("Ready\r\n"));

	UART_enableRxInterrupt();

	int length = 0;
	int etherLength = 0;
	//int uartAvailable = 0;
	//uint8_t cc1101Length = 0;
	uint8_t established = 0;
	//uint8_t etherrecv = 0;
	uint8_t etherstat = 0;
	//bool receivingmode = false;

	while (1) {

		// Check Ethernet status
		etherstat = Ethernet_status(1);

		//When client is connected
		if (etherstat == SnSR_ESTABLISHED) {
			if (!established) {
				established = 1;
				UART_WriteString("Client connected\r\n",
						strlen("Client connected\r\n"));
				sprintf((char*) buffer, "Welcome at Basis ID: 0x%X (%d) \r\n",
						(int) MY_BASE_ID, (int) MY_BASE_ID);
#if ETHERNET_ENCRYPTION
				uint8_t length = Encrypt_AES128CBC(buffer,
						strlen((char*) buffer), AES_encryption_key,
						AES_initVector);
#else
				uint8_t length = strlen((char*) buffer);

#endif
				Ethernet_write(1, buffer, length);
				memset(buffer, '\0', sizeof(buffer));
			}

			//Check if data is available
			etherLength = Ethernet_data_available(1);
			if (etherLength > 0) {
				length = etherLength;
				Ethernet_read(1, buffer, length);
#if ETHERNET_ENCRYPTION
				length = Decrypt_AES128CBC(buffer, AES_decryption_key,
						AES_initVector);
#endif

#if PRINT
				UART_WriteString((char *) buffer, length);
#endif
				//etherrecv = 1;
			}
		}

		/*		if (!receivingmode) {
		 radio_receive_packet_polling_init(&xfer, CC1101_receive);
		 receivingmode = true;
		 }

		 if (receivingmode) {
		 radio_receive_packet_polling(&xfer, &cc1101Length);
		 if (cc1101Length) {
		 // Decrypt received packet (AES128CBC)
		 RFPacket_decrypt_AES128CBC(CC1101_receive, AES_decryption_key,
		 AES_initVector);

		 // Only if message is addressed to me and checksum is correct
		 uint32_t destination_addr = (((uint32_t) CC1101_receive[3])
		 << 16 | ((uint32_t) CC1101_receive[4]) << 8
		 | CC1101_receive[5]);

		 // Check Message Type
		 uint8_t MESSAGE_TYPE = CC1101_receive[6];

		 // Check CRC
		 bool checksum_ok = RFPacket_check_crc16(CC1101_receive);

		 // Only if packet is addressed to me && Message type correct && checksum correct
		 if (destination_addr == MY_BASE_ID
		 && MESSAGE_TYPE == CC_OPT_BYTE_MSG_IDENTIFIER_TO_BASIS
		 && checksum_ok) {

		 //int8_t ccrssi = cc1101_read_rssi();

		 uint32_t identifier_addr = (((uint32_t) CC1101_receive[0])
		 << 16 | ((uint32_t) CC1101_receive[1]) << 8
		 | CC1101_receive[2]);

		 // Set CC1101 RF Module to Data Communication Configuration
		 cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG,
		 paTableData);

		 // Acknowledge reception of data from identifier
		 cc1101_ack_reception(&xfer, &MY_BASE_ID, &identifier_addr,
		 AES_encryption_key, AES_initVector);

		 // Set CC1101 RF Module to Data Communication Configuration
		 cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG,
		 paTableData);

		 // DEBUG:
		 sprintf(string_buffer,
		 "Received Packet from Identifier: 0x%X \r\n",
		 (int) identifier_addr);
		 UART_WriteString(string_buffer, sizeof(string_buffer));
		 if (Ethernet_status(1) == SnSR_ESTABLISHED) {
		 uint8_t length = Encrypt_AES128CBC(
		 (uint8_t *) string_buffer, AES_encryption_key,
		 AES_initVector);
		 Ethernet_write(1, (uint8_t *) string_buffer, length);
		 }
		 memset(string_buffer, '\0', sizeof(string_buffer));

		 uint8_t length = CC1101_receive[7], i = 0;

		 for (i = 0; i < length; i++) {
		 string_buffer[i] = CC1101_receive[i + 10];
		 }
		 UART_WriteString(string_buffer, sizeof(string_buffer));
		 if (Ethernet_status(1) == SnSR_ESTABLISHED) {
		 uint8_t length = Encrypt_AES128CBC(
		 (uint8_t *) string_buffer, AES_encryption_key,
		 AES_initVector);
		 Ethernet_write(1, (uint8_t *) string_buffer, length);
		 }
		 memset(string_buffer, '\0', sizeof(string_buffer));

		 strcpy(string_buffer, "\r\n\r\n");
		 UART_WriteString(string_buffer, sizeof(string_buffer));
		 if (Ethernet_status(1) == SnSR_ESTABLISHED) {
		 uint8_t length = Encrypt_AES128CBC(
		 (uint8_t *) string_buffer, AES_encryption_key,
		 AES_initVector);
		 Ethernet_write(1, (uint8_t *) string_buffer, length);
		 }
		 memset(string_buffer, '\0', sizeof(string_buffer));
		 cc1101Length = 0;
		 }
		 receivingmode = false;
		 memset(CC1101_receive, '\0', sizeof(CC1101_receive));
		 }
		 }*/

		// Close connection if client disconnected
		if (etherstat == SnSR_CLOSE_WAIT) {
			Ethernet_stop(1);
			UART_WriteString("Client disconnected\r\n",
					strlen("Client disconnected\r\n"));
			continue;
		}
		if (etherstatus != 0 && etherstat == SnSR_CLOSED) {
			Ethernet_start(1, port);
			established = 0;
		}

		//uartAvailable = UART_available();

		if (uartError) {
			strcpy(string_buffer, "WRONG COMMAND\r\n");
			printMSG(string_buffer, strlen(string_buffer));
			uartError = false;
			continue;
		}

		if (uartLength) {
			length = uartLength;
			memcpy(buffer, UART_receive, length);
			memset(UART_receive, '\0', sizeof(UART_receive));
			if (echo) {
				// send back command
				UART_WriteString((char *) buffer, length);
			}
		}
		if (length > 0) {
		// Command received:

			// Reset the command length
			length = 0;

			// these commands are available by ethernet and serial interface:

			// find command:
			if (memcmp(buffer, "find", 4) == 0) {
				long wake = 0;
				// Check if ID is in hex format
				if (memcmp(buffer, "find 0x", 7) == 0) {
					// potentially valid HEX command
					uint8_t hexstring[7] = { 0 };
					arraycpy(hexstring, buffer, 7, 6);
					wake = strtol((char *) hexstring, NULL, 16);

					// check if ID within range
					if (wake < 16777216) {
						// valid wake address:
						sendPacket(wake, AS_OPT_BYTE_NORMAL_MODE, NULL, 0);
					} else {
						// error:
						strcpy(string_buffer,
								"ID not valid - must be < 16777216\r\n");
						printMSG(string_buffer, strlen(string_buffer));
						error = true;
					}

				} else {
					// Not supporting decimal format, throw an error:
					strcpy(string_buffer,
							"WRONG FORMAT\r\n");
					printMSG(string_buffer, strlen(string_buffer));
					error = true;

//					// ID is in decimal format
//					char wakeupid[9] = { 0 };
//					int pos = 0;
//					while (buffer[5 + pos] != '\r') {
//						wakeupid[pos] = buffer[5 + pos];
//						pos++;
//					}
//					wakeupid[pos + 1] = '\0';
//					wake = atoi(wakeupid);
				}


			// broadcast command:
			} else if (memcmp(buffer, "broadcast", 9) == 0) {
				long wake = 0;
				// Check if ID is in hex format
				// TODO: function for ID extract
				if (memcmp(buffer, "broadcast 0x", 12) == 0) {
					uint8_t hexstring[7] = { 0 };
					arraycpy(hexstring, buffer, 12, 6);
					wake = strtol((char *) hexstring, NULL, 16);
				} else { // ID is in decimal format
					char wakeupid[9] = { 0 };
					int pos = 0;
					while (buffer[10 + pos] != '\r') {
						wakeupid[pos] = buffer[10 + pos];
						pos++;
					}
					wakeupid[pos + 1] = '\0';
					wake = atoi(wakeupid);
				}
				if (wake < 256) {
					sprintf(string_buffer, "Sending Broadcast 0x%X\r\n",
							(int) wake);
					printMSG(string_buffer, strlen(string_buffer));
					cc1101_change_config_to(CC1101_WAKEUP_CONFIG_NARROW_BAND,
							paTableWakeUp);

					// switch to send wakeup mode (use CC1190)
#if REVISION != BASE_REV_1
					BASE_ANTENNA_switch(SKY_DEST_CC1190, PE_DEST_CC1190,
							antUse);
#endif
					cc1190_send();

					cc1101_send_broadcast_packet(&xfer, wake);

#if REVISION != BASE_REV_1
					// switch to receive / transmit data mode
					BASE_ANTENNA_switch(SKY_DEST_PE, PE_DEST_SKY, antUse);
#endif
					cc1190_receive();

					// Check that Identifier has received wake up
					cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG,
							paTableData);

				} else {
					strcpy(string_buffer, "ID not valid - must be < 256\r\n");
					printMSG(string_buffer, strlen(string_buffer));
					error = true;
				}

			// transmit to terminal command, not used so far (TODO: check or remove)
			} else if (memcmp(buffer, "transmitToTerminal", 18) == 0) {
				long wake = 0;
				uint8_t comLength = 0;
				uint8_t data[200] = { 0 };
				// Check if ID is in hex format
				if (memcmp(buffer, "transmitToTerminal 0x", 21) == 0) {
					uint8_t hexstring[7] = { 0 };
					arraycpy(hexstring, buffer, 21, 6);
					comLength = getIdLength(hexstring, 20) + 11;
					wake = strtol((char *) hexstring, NULL, 16);
				} else { // ID is in decimal format
					char wakeupid[9] = { 0 };
					int pos = 0;
					while (buffer[19 + pos] != ' ') {
						wakeupid[pos] = buffer[19 + pos];
						pos++;
					}
					wakeupid[pos + 1] = '\0';
					comLength = getIdLength((uint8_t *) wakeupid, 20) + 19;
					wake = atoi(wakeupid);
				}
				if (wake < 16777216) {
					uint8_t len = buffer[comLength + 1];
					uint8_t i;
					for (i = 0; i < (len + 2); i++) {
						data[i] = buffer[i + comLength + 3];
					}
					sendPacket(wake, CC_OPT_BYTE_MSG_BASIS_TO_TERMINAL, data,
							i);
				} else {
					strcpy(string_buffer,
							"ID not valid - must be < 16777216\r\n");
					printMSG(string_buffer, strlen(string_buffer));
					error = true;
				}
				memset(buffer, '\0', sizeof(buffer));

			// transmit command:
			} else if (memcmp(buffer, "transmit", 8) == 0) {
				long wake = 0;
				uint8_t comLength = 0;
				uint8_t data[255] = { 0 }; // increased size to 255 in order to append \0 if length expression is longer than expected data

				// Check if ID is in hex format
				if (memcmp(buffer, "transmit 0x", 11) == 0) {
					uint8_t hexstring[7] = { 0 };
					arraycpy(hexstring, buffer, 11, 6);
					comLength = getIdLength(hexstring, 0) + 11;
					wake = strtol((char *) hexstring, NULL, 16);
				} else { // ID is in decimal format
					char wakeupid[9] = { 0 };
					int pos = 0;
					while (buffer[9 + pos] != ' ') {
						wakeupid[pos] = buffer[9 + pos];
						pos++;
					}
					wakeupid[pos + 1] = '\0';
					comLength = getIdLength((uint8_t *) wakeupid, 0) + 9;
					wake = atoi(wakeupid);
				}

				// process for valid wake-up id:
				if (wake < 16777216) {
					uint8_t i;

					// TODO: implement error message for wrong command format

					//Search for second space ' '
					uint8_t secondSpace = 9 + getIdSpace(buffer, 9);
					comLength = secondSpace;
					//Search for third space ' '
					uint8_t thirdSpace = secondSpace + 1 + getIdSpace(buffer, secondSpace + 1);

					if((secondSpace > 17) || (thirdSpace == secondSpace) || (thirdSpace-secondSpace > 4)) {
						// WRONG COMMAND
						strcpy(string_buffer,
								"WRONG FORMAT\r\n");
						printMSG(string_buffer, strlen(string_buffer));
						error = true;
					} else {
						//extract String containing the data length:
						uint8_t lengthString[4] = { 0 };
						arraycpy(lengthString, buffer, secondSpace + 1, thirdSpace-secondSpace);
						//parse string to data length integer:
						datLength = atoi((char *)lengthString);

						if(datLength > 200) {
							strcpy(string_buffer,
									"DATA TOO LONG\r\n");
							printMSG(string_buffer, strlen(string_buffer));
							error = true;
						} else {
							// extract data from buffer:
							for (i = 0; i < datLength; i++) {
								if (datLength > 99) {
									data[i] = buffer[i + comLength + 5];
								} else if (datLength > 9) {
									data[i] = buffer[i + comLength + 4];
								} else {
									data[i] = buffer[i + comLength + 3];
								}
							}

							// send data
							sendPacket(wake, AS_OPT_BYTE_DATA_MODE, data, datLength);
						}
					}
				} else {
					strcpy(string_buffer,
							"ID not valid - must be < 16777216\r\n");
					printMSG(string_buffer, strlen(string_buffer));
					error = true;
				}
			} else if (memcmp(buffer, "initialize", 10) == 0) {
				long wake = 0;
				uint8_t comLength = 0;
				uint8_t data[200] = { 0 };
				// Check if ID is in hex format
				if (memcmp(buffer, "initialize 0x", 13) == 0) {
					uint8_t hexstring[7] = { 0 };
					arraycpy(hexstring, buffer, 13, 6);
					comLength = getIdLength(hexstring, 0) + 13;
					wake = strtol((char *) hexstring, NULL, 16);
				} else { // ID is in decimal format
					char wakeupid[9] = { 0 };
					int pos = 0;
					while (buffer[10 + pos] != ' ') {
						wakeupid[pos] = buffer[10 + pos];
						pos++;
					}
					wakeupid[pos + 1] = '\0';
					comLength = getIdLength((uint8_t *) wakeupid, 0) + 10;
					wake = atoi(wakeupid);
				}
				if (wake < 16777216) {
					uint8_t len = getBufferLength(buffer);
					len = len - comLength - 1;
					uint8_t i;
					for (i = 0; i < len; i++) {
						data[i] = buffer[i + comLength + 1];
					}
					sendPacket(wake, AS_OPT_BYTE_SERVICE_MODE, data, i);
				} else {
					strcpy(string_buffer,
							"ID not valid - must be < 16777216\r\n");
					printMSG(string_buffer, strlen(string_buffer));
					error = true;
				}

			// getState command:
			} else if (memcmp(buffer, "getState", 8) == 0) {
				long wake = 0;
				// Check if ID is in hex format
				if (memcmp(buffer, "getState 0x", 11) == 0) {
					// potentially valid HEX command
					uint8_t hexstring[7] = { 0 };
					arraycpy(hexstring, buffer, 11, 6);
					wake = strtol((char *) hexstring, NULL, 16);

					// check if ID within range
					if (wake < 16777216) {
						// valid wake address:
						sendPacket(wake, AS_OPT_BYTE_STATUS_MODE, NULL, 0);
					} else {
						// error:
						strcpy(string_buffer,
								"ID not valid - must be < 16777216\r\n");
						printMSG(string_buffer, strlen(string_buffer));
						error = true;
					}

				} else {
					// Not supporting decimal format, throw an error:
					strcpy(string_buffer,
							"WRONG FORMAT\r\n");
					printMSG(string_buffer, strlen(string_buffer));
					error = true;

//					// ID is in decimal format
//					char wakeupid[9] = { 0 };
//					int pos = 0;
//					while (buffer[5 + pos] != '\r') {
//						wakeupid[pos] = buffer[5 + pos];
//						pos++;
//					}
//					wakeupid[pos + 1] = '\0';
//					wake = atoi(wakeupid);
				}
#if REVISION != BASE_REV_1
			} else if (memcmp(buffer, "useAntenna", 10) == 0) {
				uint8_t tmpbuffer[8] = { 0 };
				arraycpy(tmpbuffer, buffer, 11, 2);
				if (memcmp(tmpbuffer, "1", 1) == 0) {
					antUse = ANT1;

				} else if (memcmp(tmpbuffer, "2", 1) == 0) {
					antUse = ANT2;

				} else {
					strcpy(string_buffer,
							"Wrong form! Use: useAntenna 1 / 2\r\n");
					UART_WriteString(string_buffer, sizeof(string_buffer));
					memset(string_buffer, '\0', sizeof(string_buffer));
					error = true;
				}
#endif
			} else if (memcmp(buffer, "exit\r\n", sizeof("exit\r\n")) == 0) {
				Ethernet_stop(1);
				UART_WriteString("Client disconnected\r\n",
						sizeof("Client disconnected\r\n"));
				continue;
			} else if (memcmp(buffer, "\r\n", sizeof("\r\n")) == 0) {
				error = true;
			} else if (uartLength > 0) {// these commands only available via serial
				if (memcmp(buffer, "setIP", 5) == 0) {
					uint8_t tempip[4] = { 0 };
					uint8_t buffip[17] = { 0 };
					arraycpy(buffip, buffer, 6, 17);
					int status = stringToIP(buffip, tempip);
					if (status == 4) {
						EEPROM_write_ip(tempip);
					} else {
						strcpy(string_buffer,
								"Wrong form! IP form: XXX.XXX.XXX.XXX (XXX = 0 - 255)\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						error = true;
					}
				} else if (memcmp(buffer, "setSubnetMask", 13) == 0) {
					uint8_t tempip[4] = { 0 };
					uint8_t buffip[17] = { 0 };
					arraycpy(buffip, buffer, 14, 17);
					int status = stringToIP(buffip, tempip);
					if (status == 4) {
						EEPROM_write_subnetmask(tempip);
					} else {
						strcpy(string_buffer,
								"Wrong form! Subnet Mask form: XXX.XXX.XXX.XXX (XXX = 0 - 255)\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						error = true;
					}
				} else if (memcmp(buffer, "setGateway", 10) == 0) {
					uint8_t tempip[4] = { 0 };
					uint8_t buffip[17] = { 0 };
					arraycpy(buffip, buffer, 11, 17);
					stringToIP(buffip, tempip);
					int status = stringToIP(buffip, tempip);
					if (status == 4) {
						EEPROM_write_gateway(tempip);
					} else {
						strcpy(string_buffer,
								"Wrong form! IP form: XXX.XXX.XXX.XXX (XXX = 0 - 255)\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						error = true;
					}
				} else if (memcmp(buffer, "DHCP", 4) == 0) {
					uint8_t tmpbuffer[8] = { 0 };
					arraycpy(tmpbuffer, buffer, 5, 7);
					if (memcmp(tmpbuffer, "enable", 6) == 0) {
						EEPROM_write_dhcp(1);

					} else if (memcmp(tmpbuffer, "disable", 7) == 0) {
						EEPROM_write_dhcp(0);
					} else {
						strcpy(string_buffer,
								"Wrong form! Use: DHCP enable / DHCP disable\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						memset(string_buffer, '\0', sizeof(string_buffer));
						error = true;
					}
				} else if (memcmp(buffer, "setPort", 7) == 0) {
					uint8_t tport[6] = { 0 };
					arraycpy(tport, buffer, 8, 5);
					uint16_t tempport = (uint16_t) atoi((char *) tport);
					if (tempport < 65536) {
						EEPROM_write_tcpport(tempport);
					} else {
						strcpy(string_buffer,
								"Wrong Port number - must be < 65536\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						memset(string_buffer, '\0', sizeof(string_buffer));
						error = true;
					}
				} else if (memcmp(buffer, "setID", 5) == 0) {
					long id = 0;
					// Check if ID is in hex format
					if (memcmp(buffer, "setID 0x", 8) == 0) {
						uint8_t hexstring[7] = { 0 };
						arraycpy(hexstring, buffer, 8, 6);
						id = strtol((char *) hexstring, NULL, 16);
					} else { // ID is in decimal format
						char baseid[9] = { 0 };
						int pos = 0;
						while (buffer[6 + pos] != '\r') {
							baseid[pos] = buffer[6 + pos];
							pos++;
						}
						baseid[pos + 1] = '\0';
						id = atoi(baseid);
					}
					if (id < 16777216) {
						EEPROM_write_id((uint32_t *) &id);
						Dhcp_setID((uint32_t *) &id);
					} else {
						strcpy(string_buffer,
								"ID not valid - must be < 16777216\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						memset(string_buffer, '\0', sizeof(string_buffer));
						error = true;
					}
				} else if (memcmp(buffer, "setAESKey", 9) == 0) {
					char tmpkey[16] = { 0 };
					int pos = 0;
					while (buffer[pos + 10] != '\r') {
						if (pos < 16) {
							tmpkey[pos] = buffer[pos + 10];
						}
						pos++;
					}
					if (pos == 16) {
						for (int i = 0; i < 16; i++) {
							AES_encryption_key[i] = tmpkey[i];
						}
						EEPROM_write_aes(AES_encryption_key);
						/* Calculate the new decryption key from the original key */
						AES_DecryptKey128(AES_decryption_key,
								AES_encryption_key);
						//TODO: Send to Identifier
					} else {
						strcpy(string_buffer,
								"Wrong Key size! AESKey form: STRING(16 chars)\r\n");
						UART_WriteString(string_buffer, strlen(string_buffer));
						memset(string_buffer, '\0', sizeof(string_buffer));
						error = true;
					}
				} else {
					error = true;
				}
			} else {
				error = true;
			}

			if (error) {
				//USART_Tx(USART1, 0x07);
				strcpy(string_buffer, "NACK\r\n");
				printMSG(string_buffer, strlen(string_buffer));
				error = false;
				uartLength = 0;
			} else {
				strcpy(string_buffer, "ACK\r\n");
				printMSG(string_buffer, strlen(string_buffer));
				error = false;
				uartLength = 0;
			}
			memset(buffer, '\0', sizeof(buffer));
		}
	}
#endif
}
#if MODE == NORMAL
/*
 * Function: sendPacket
 * ----------------------------
 *   Send to Identifier with different options
 *
 *   wakeupid: ID of the Identifier
 *   option: option byte
 *   *data: ptr to data array (Null if no data is needed)
 *   len: length of data to send
 *
 */

void sendPacket(uint32_t wakeupid, uint8_t option, uint8_t *data, uint8_t len) {

	error = false;

	memset(string_buffer, '\0', sizeof(string_buffer));

	uint8_t CC1101_receive[256] = { 0 };
	uint8_t CC1101_send[256] = { 0 };
	uint8_t CC1101_data[256] = { 0 };
	uint8_t CC_length = 0;
	int8_t ccrssi = 0;

	if (option != CC_OPT_BYTE_MSG_BASIS_TO_TERMINAL) {
		//Send Wakeup
		// Try to send the wakeup again if it fails
		for (int i = 0; i < NUM_SEND_RETRY; i++) {
#if PRINT
			sprintf(string_buffer,
					"Sending WakeUp to 0x%X with Antenna: %d and Option: 0x%X ... \r\n",
					(int) wakeupid, (int) antUse, (int) option);
			printMSG(string_buffer, strlen(string_buffer));
#endif
			// Set CC1101 RF Module to WakeUp Configuration
			cc1101_spi_init(CC1101_SPI_BAUDRATE);
			//cc1101_change_config_to(CC1101_WAKEUP_CONFIG, PLUS_12dBm);
			cc1101_change_config_to(CC1101_WAKEUP_CONFIG_NARROW_BAND,
					paTableWakeUp);

#if REVISION != BASE_REV_1
			// switch to send wakeup mode (use CC1190)
			BASE_ANTENNA_switch(SKY_DEST_CC1190, PE_DEST_CC1190, antUse);
#endif
			cc1190_send();

			// Send WakeUp Packet
			cc1101_send_wakeup_packet_24bit_addr(&xfer, wakeupid, MY_BASE_ID,
					option);

#if REVISION != BASE_REV_1
			// switch to receive / transmit data mode
			BASE_ANTENNA_switch(SKY_DEST_PE, PE_DEST_SKY, antUse);
#endif
			cc1190_receive();

			// Check if ack is received
			if (option == AS_OPT_BYTE_SERVICE_MODE) {
				if (!cc1101_check_ack(&xfer, &wakeupid, &MY_BASE_ID,
						AES_decryption_public_key, AES_initVector, 500)) {
					error = true;
				} else {
					error = false;
					break;
				}
			} else {
				if (!checkACK(wakeupid)) {
					error = true;
#if REVISION != BASE_REV_1
	#if SWITCH_ANTENNA
					if (antUse) {
						antUse = ANT2;
					} else {
						antUse = ANT1;
					}
	#endif
#endif
				} else {
					error = false;
					break;
				}
			}
		}
		if (error) {
			return;
		}
	}

	// Set CC1101 RF Module to Data Communication Configuration
	cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);

	if (data != 0 && option != AS_OPT_BYTE_SERVICE_MODE) { // Send data

		// Build Header
		RFPacket_build_header(CC1101_send, data, &MY_BASE_ID, &wakeupid,
				CC_OPT_BYTE_DAT_BASIS_TO_IDENTIFIER, &len);

		// Add length byte for CC
		RFPacket_add_cc_length(CC1101_send, &len);

		// Encrypt send packet (AES128CBC)
		RFPacket_encrypt_AES128CBC(CC1101_send, &len, AES_encryption_key,
				AES_initVector);
#if PRINT
		UART_WriteString("send ... ", sizeof("send ... "));
#endif
		// Send packet
		cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
		radio_send_packet(&xfer, CC1101_send, len);

		// Change config to
		cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);

		// Check if ack is received
		uint32_t identifier_addr = 0;
		listenForResponse(CC1101_receive, wakeupid,
				CC_OPT_BYTE_MSG_IDENTIFIER_TO_BASIS, &len, &ccrssi,
				&identifier_addr);
		if (error) {
			return;
		}
		strcpy(string_buffer, "UART ");
		strcat(string_buffer, (char *) CC1101_receive);
		strcat(string_buffer, "\r\n");
		printMSG(string_buffer, strlen(string_buffer));

#if PRINT
		UART_WriteString("finished\r\n", sizeof("finished\r\n"));
#endif

	} else if (option == AS_OPT_BYTE_STATUS_MODE) {
		// getState
		uint32_t identifier_addr = 0;
		listenForResponse(CC1101_receive, wakeupid,
				CC_OPT_BYTE_MSG_IDENTIFIER_TO_BASIS, &len, &ccrssi,
				&identifier_addr);
		if (error) {
			return;
		}

#if PRINT
		// DEBUG:
		sprintf(string_buffer,
				"Received Packet from Identifier: 0x%X BAT: %dmV AS-RSSI: %ddB CC-RSSI: %ddBm Options: %d \r\n",
				(int) identifier_addr,
				(int) ((uint16_t) CC1101_receive[1]) << 8 | CC1101_receive[2],
				(int) CC1101_receive[0], (int) ccrssi, CC1101_receive[3]);
		printMSG(string_buffer, strlen(string_buffer));
#else
		uint8_t tmpBuffer[256] = { 0 };
		int buflength = 0;
		// Format: Identifier, Bat Voltage, Options, Data-Length, Data
		sprintf(string_buffer, "0x%X,%d,%d,%d", (int) identifier_addr,
				(int) ((uint16_t) CC1101_receive[1]) << 8 | CC1101_receive[2],
				(int) CC1101_receive[3], (int) CC1101_receive[4]);
		buflength = strlen(string_buffer);
		strcat((char*) tmpBuffer, string_buffer);
		if (CC1101_receive[4] != 0) {
			strcat((char*) tmpBuffer, ",");
			for (uint8_t j = 0; j < CC1101_receive[4]; j++) {
				tmpBuffer[j + buflength + 1] = CC1101_receive[j + 5];
			}
			buflength += CC1101_receive[4] + 1;
		}
		tmpBuffer[buflength] = '\r';
		tmpBuffer[buflength + 1] = '\n';
		buflength += 2;
		UART_Write(tmpBuffer, buflength);
		if (Ethernet_status(1) == SnSR_ESTABLISHED) {
#if ETHERNET_ENCRYPTION
			uint8_t length = Encrypt_AES128CBC((uint8_t *) tmpBuffer, buflength,
					AES_encryption_key, AES_initVector);
#else
			uint8_t length = buflength;
#endif
			if (Ethernet_write(1, (uint8_t *) tmpBuffer, length) == 0) {
				// Something went wrong on transmitting data
				error = true;
			}
		}
		memset(string_buffer, '\0', sizeof(string_buffer));
#endif
	} else if (data != 0 && option == AS_OPT_BYTE_SERVICE_MODE) { // Initialize
		// Build send packet
		uint8_t new_encrypt_key[16] = { 0 };
		uint32_t newID = 0;
		uint32_t newWakeUpAddr = 0;

		// Parse data
		uint8_t tmpID[10] = { 0 };
		uint8_t tmpWakeUpAddr[10] = { 0 };

		uint8_t idLen = getIdLength(data, 0);
		uint8_t wakeLen = getIdLength(data, idLen + 1);

		// Check the AES-Key length
		if (getIdLength(data, idLen + wakeLen + 2) != 16) {
			error = true;
			return;
		}

		arraycpy(tmpID, data, 0, idLen);
		arraycpy(tmpWakeUpAddr, data, idLen + 1, wakeLen);
		arraycpy(new_encrypt_key, data, idLen + wakeLen + 2, 16);
		uint8_t comlen = 0;
		if (memcmp(tmpID, "0x", 2) == 0) {
			comlen = 2;
			getID(tmpID, &newID, &comlen, 0, true);
		} else {
			comlen = 0;
			getID(tmpID, &newID, &comlen, 0, false);
		}
		if (memcmp(tmpWakeUpAddr, "0x", 2) == 0) {
			comlen = 2;
			getID(tmpWakeUpAddr, &newWakeUpAddr, &comlen, 0, true);
		} else {
			comlen = 0;
			getID(tmpWakeUpAddr, &newWakeUpAddr, &comlen, 0, false);
		}

		// Clear buffers
		memset(CC1101_data, 0x00, sizeof(CC1101_data));
		memset(CC1101_send, 0x00, sizeof(CC1101_send));
		CC_length = 0;

		// New AES KEY
		CC1101_data[CC_length++] = new_encrypt_key[0];
		CC1101_data[CC_length++] = new_encrypt_key[1];
		CC1101_data[CC_length++] = new_encrypt_key[2];
		CC1101_data[CC_length++] = new_encrypt_key[3];
		CC1101_data[CC_length++] = new_encrypt_key[4];
		CC1101_data[CC_length++] = new_encrypt_key[5];
		CC1101_data[CC_length++] = new_encrypt_key[6];
		CC1101_data[CC_length++] = new_encrypt_key[7];
		CC1101_data[CC_length++] = new_encrypt_key[8];
		CC1101_data[CC_length++] = new_encrypt_key[9];
		CC1101_data[CC_length++] = new_encrypt_key[10];
		CC1101_data[CC_length++] = new_encrypt_key[11];
		CC1101_data[CC_length++] = new_encrypt_key[12];
		CC1101_data[CC_length++] = new_encrypt_key[13];
		CC1101_data[CC_length++] = new_encrypt_key[14];
		CC1101_data[CC_length++] = new_encrypt_key[15];

		// New ID
		CC1101_data[CC_length++] = newID >> 16;
		CC1101_data[CC_length++] = newID >> 8;
		CC1101_data[CC_length++] = newID >> 0;

		// New WAKEUP Address
		CC1101_data[CC_length++] = newWakeUpAddr >> 16;
		CC1101_data[CC_length++] = newWakeUpAddr >> 8;
		CC1101_data[CC_length++] = newWakeUpAddr >> 0;

		// Build Header
		RFPacket_build_header(CC1101_send, CC1101_data, &MY_BASE_ID, &wakeupid,
				CC_OPT_BYTE_MSG_SERVICE, &CC_length);

		// Add length byte for CC1101
		RFPacket_add_cc_length(CC1101_send, &CC_length);

		// Encrypt send packet (AES128CBC)
		RFPacket_encrypt_AES128CBC(CC1101_send, &CC_length,
				AES_encryption_public_key, AES_initVector);

		// Send
		radio_send_packet(&xfer, CC1101_send, CC_length);

		// Wait while programming
		RTC_delay_ms(300);

		// Wait for ACK
		RTC_start(1000);
		while (!RTC_TIMEOUT) {
			cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
			bool ack = cc1101_check_ack(&xfer, &wakeupid, &MY_BASE_ID,
					AES_decryption_public_key, AES_initVector, 500);
			if (ack) {
#if PRINT
				UART_WriteString("SUCCESS!\r\n", sizeof("SUCCESS!\r\n"));
#endif
				break;
			}
		}
		if (RTC_TIMEOUT) {
#if PRINT
			UART_WriteString("NO SUCCESS!\r\n", sizeof("NO SUCCESS!\r\n"));
#endif
			error = true;
			return;
		}

	} else {
		// Find the identifier
		uint32_t identifier_addr = 0;
		listenForResponse(CC1101_receive, wakeupid,
				CC_OPT_BYTE_MSG_IDENTIFIER_TO_BASIS, &len, &ccrssi,
				&identifier_addr);
		if (error) {
			return;
		}

#if PRINT
		// DEBUG:
		sprintf(string_buffer,
				"Received Packet from Identifier: 0x%X BAT: %dmV AS-RSSI: %ddB CC-RSSI: %ddBm Table_Responses: %d \r\n",
				(int) identifier_addr,
				(int) ((uint16_t) CC1101_receive[2]) << 8 | CC1101_receive[3],
				(int) CC1101_receive[1], (int) ccrssi, CC1101_receive[0]);
		printMSG(string_buffer, strlen(string_buffer));

		uint8_t j = 0, k = 4;
		for (j = 0; j < CC1101_receive[0]; j++) {
			sprintf(string_buffer,
					"TableID: 0x%X | AS_RSSI: %ddB | CC_RSSI: %ddBm | BAT: %dmV \r\n",
					(int) (((uint32_t) CC1101_receive[k]) << 16
							| ((uint32_t) CC1101_receive[k + 1]) << 8
							| CC1101_receive[k + 2]), CC1101_receive[k + 3],
					(int8_t) CC1101_receive[k + 4],
					(int) ((uint16_t) CC1101_receive[k + 5]) << 8
					| CC1101_receive[k + 6]);
			printMSG(string_buffer, strlen(string_buffer));
			k += 7;
		}
		strcpy(string_buffer, "\r\n\r\n");
		printMSG(string_buffer, strlen(string_buffer));
#else
		char tmpString[128] = { 0 };
		// Format: Identifier-ID, #Tables, Table1-ID, Table1-RSSI, Table1-BAT, Table2-ID, Table2-RSSI, Table2-BAT, �
		sprintf(tmpString, "0x%X,%d,%d", (int) identifier_addr,
				(int) ((uint16_t) CC1101_receive[2]) << 8 | CC1101_receive[3],
				CC1101_receive[0]);
		strcat(string_buffer, tmpString);
		memset(tmpString, 0x00, sizeof(tmpString));
		//printMSG(string_buffer, sizeof(string_buffer));
		uint8_t j = 0, k = 4;
		for (j = 0; j < CC1101_receive[0]; j++) {
			sprintf(tmpString, ",0x%X,%d,%d",
					(int) (((uint32_t) CC1101_receive[k]) << 16
							| ((uint32_t) CC1101_receive[k + 1]) << 8
							| CC1101_receive[k + 2]),
					(int8_t) CC1101_receive[k + 4],
					(int) ((uint16_t) CC1101_receive[k + 5]) << 8
							| CC1101_receive[k + 6]);
			strcat(string_buffer, tmpString);
			memset(tmpString, 0x00, sizeof(tmpString));
			//printMSG(string_buffer, sizeof(string_buffer));
			k += 7;
		}
		strcat(string_buffer, "\r\n");
		printMSG(string_buffer, strlen(string_buffer));
#endif
	}

#if PRINT
	GPIO_PinOutSet(LEDPort, green);
	RTC_delay_ms(125);
	GPIO_PinOutClear(LEDPort, green);
#endif
}

/*
 * Function: listenForResponse
 * ----------------------------
 *   wait for response within 3000 microseconds
 *
 *   *buffer: ptr to byte array for received data
 *   wakeupid: identifier ID
 *   msgType: type of message
 *   *len: ptr to length of data
 *
 */

void listenForResponse(uint8_t *buffer, uint32_t wakeupid, uint8_t msgType,
		uint8_t *len, int8_t *ccrssi, uint32_t *identifier_addr) {

	RTC_start(3000);

	while (!RTC_TIMEOUT) {
		memset(buffer, 0x00, sizeof(buffer));
		// Receive Data from Identifier
		radio_receive_packet(&xfer, buffer, len, 100);

		*ccrssi = cc1101_read_rssi();

		// Decrypt received packet (AES128CBC)
		RFPacket_decrypt_AES128CBC(buffer, AES_decryption_key, AES_initVector);

		*identifier_addr = (((uint32_t) buffer[0]) << 16
				| ((uint32_t) buffer[1]) << 8 | buffer[2]);

		if (!RFPacket_check_and_remove_header(buffer, &wakeupid, &MY_BASE_ID,
				&msgType)) {
			// Packet is not addressed to me or has the wrong type
			continue;
		}

		// Set CC1101 RF Module to Data Communication Configuration
		cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);

		// Acknowledge reception of data from identifier
		cc1101_ack_reception(&xfer, &MY_BASE_ID, identifier_addr,
				AES_encryption_key, AES_initVector);

		// Set CC1101 RF Module to Data Communication Configuration
		cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
		return;
	}
	error = true;
}

/*
 * Function: checkACK
 * ----------------------------
 *   check if ack is received within 500 ms
 *
 *   wakeupid: identifier ID
 *
 *   returns: state of ack
 */

bool checkACK(uint32_t wakeupid) {
// Check that Identifier has received wake up
	bool ack = false;
	// Wait for ACK
	RTC_start(180);
	while (!RTC_TIMEOUT) {
		cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
		ack = cc1101_check_ack(&xfer, &wakeupid, &MY_BASE_ID,
				AES_decryption_key, AES_initVector, 200);
		if (ack) {
			break;
		}
	}
	if (RTC_TIMEOUT) {
#if PRINT
		UART_WriteString("TIMEOUT!\r\n", sizeof("TIMEOUT!\r\n"));
#endif
		error = true;
	}
#if PRINT
	if (ack) {
		strcpy(string_buffer, "ACK!\r\n");
		printMSG(string_buffer, strlen(string_buffer));
	} else {
		strcpy(string_buffer, "NOT ACK!\r\n\r\n");
		printMSG(string_buffer, strlen(string_buffer));
	}
#endif
	return ack;
}

/*
 * Function: Encrypt_AES128CBC
 * ----------------------------
 *   encrypt message with AES128CBC
 *
 *   *buffer: ptr to byte array with msg
 *   *key: ptr to encryptionkey
 *   *iv: ptr to initial vector
 *
 *   returns: length of the encrypted msg
 */

uint8_t Encrypt_AES128CBC(uint8_t *buffer, uint8_t len, const uint8_t *key,
		const uint8_t *iv) {
	uint8_t length = len;
	len = ((len - 1) | 15) + 1;  // Must be a multiple of 16

	uint8_t AESBuffer[len];
	memset(AESBuffer, 0x00, len);

	memcpy(AESBuffer, buffer, length);

	/* Encrypt data in AES_128 CBC */
	AES_CBC128(AESBuffer, AESBuffer, len, key, iv, true);

	memset(buffer, 0x00, sizeof(buffer));
	memcpy(buffer, AESBuffer, len);

	return len;
}

/*
 * Function: Decrypt_AES128CBC
 * ----------------------------
 *   Decrypt message with AES128CBC
 *
 *   *buffer: ptr to byte array with msg
 *   *key: ptr to decryptionkey
 *   *iv: ptr to initial vector
 *
 *   returns: length of the decrypted msg
 */

uint8_t Decrypt_AES128CBC(uint8_t *buffer, const uint8_t *key,
		const uint8_t *iv) {
//uint8_t len = getBufferLength(buffer);

	uint8_t len = 0;
	while (!(buffer[len] == '\0' && buffer[len + 1] == '\0')) {
		len++;
	}

	AES_CBC128(buffer, buffer, len, key, iv, false);
	buffer[len] = '\r';
	buffer[len + 1] = '\n';

	return len;
}

/*
 * Function: arraycpy
 * ----------------------------
 *   Copy an array from an start- to an endpoint
 *
 *   *dest: ptr to destination
 *   *src: ptr to source
 *   start: start position in source
 *   len: number of bytes
 *
 */

void arraycpy(uint8_t *dest, uint8_t *src, int start, int len) {
	for (int i = 0; i < len; i++) {
		dest[i] = src[start + i];
	}
}

/*
 * Function: stringToIP
 * ----------------------------
 *   Converts an IP String to an 4 byte array
 *
 *   *buffer: ptr to stringbuffer with IP
 *   *ip: ptr to 4 byte array for IP
 *
 *   returns: number of bytes
 */

int stringToIP(uint8_t *buffer, uint8_t *ip) {
	char iptemp[4] = { 0 };
	char number[4] = { 0 };
	int pos = 0;
	int num = 0;
	int ret = 0;
	while (buffer[pos + 1] != '\n' && num < 4) {
		if (buffer[pos] == '.') {
			iptemp[ret] = atoi(number);
			pos++;
			ret++;
			num = 0;
			memset(number, '\0', 4);
		}
		if (buffer[pos] >= '0' && buffer[pos] <= '9') {
			number[num] = buffer[pos];
			pos++;
			num++;
		} else {
			return 0;
		}
	}
	if (memcmp(number, "\r", 1) == 0) {
		return 0;
	}
	iptemp[ret] = atoi(number);
	ret++;

	for (int i = 0; i < 4; i++) {
		ip[i] = iptemp[i];
	}
	return ret;
}

/*
 * Function: getID
 * ----------------------------
 *   Counts the bytes until \r\n
 *
 *   *buffer: ptr to byte array
 *   *id: ptr to ID
 *   *comlen: ptr with length of command in buffer
 *   offset: offset i.e. for 0x at HEX-ID
 *   isHEX: is the ID in HEX-format
 *
 */

void getID(uint8_t *buffer, uint32_t *id, uint8_t *comlen, uint8_t offset,
		bool isHEX) {

	uint8_t idLen = getIdLength(buffer, *comlen);
	// ID is in hex format
	if (isHEX) {
		uint8_t hexstring[7] = { 0 };
		arraycpy(hexstring, buffer, *comlen + offset, idLen);
		*comlen = idLen + (*comlen + offset);
		*id = (uint32_t) strtol((char *) hexstring, NULL, 16);
	} else { // ID is in decimal format
		uint8_t wakeupid[9] = { 0 };
		arraycpy(wakeupid, buffer, *comlen, idLen);
		*comlen = idLen + *comlen;
		*id = (uint32_t) atoi((char *) wakeupid);
	}
}

/*
 * Function: getBufferLength
 * ----------------------------
 *   Counts the bytes until \r\n
 *
 *   *buffer: ptr to byte array
 *
 *   returns: number of bytes in buffer
 */

// Counts the bytes until \r\n
uint8_t getBufferLength(uint8_t *buffer) {
	uint8_t len = 0;
	while (!(buffer[len] == '\r' && buffer[len + 1] == '\n')) {
		len++;
		if (len == 255) {
			return 0;
		}
	}
	return len + 2;
}

/*
 * Function: getIdLength
 * ----------------------------
 *   Counts the bytes until \0, [space], \r
 *
 *   *buffer: ptr to byte array with ID
 *
 *   returns: number of bytes in buffer
 */

uint8_t getIdLength(uint8_t *buffer, uint8_t start) {
	uint8_t len = 0;
	while (!((buffer[start + len] == '\0') || buffer[start + len] == ' '
			|| buffer[start + len] == '\r')) {
		len++;
		if (len == 255) {
			return 0;
		}

	}
	return len;
}

uint8_t getIdSpace(uint8_t *buffer, uint8_t start) {
	uint8_t len = 0;
	while (!(buffer[start + len] == ' ') && (len < 255)) {
		len++;
	}
	return len;
}

/*
 * Function: printMSG
 * ----------------------------
 *   Prints the byte array to serial and Ethernet if
 *   client is connected
 *
 *   *buffer: ptr to byte array
 *   len: number of bytes
 *
 */
void printMSG(char *buffer, int len) {
	UART_WriteString(buffer, len);
	if (Ethernet_status(1) == SnSR_ESTABLISHED) {
#if ETHERNET_ENCRYPTION
		uint8_t length = Encrypt_AES128CBC((uint8_t *) buffer, len,
				AES_encryption_key, AES_initVector);
#else
		uint8_t length = (uint8_t) len;
#endif
		if (Ethernet_write(1, (uint8_t *) buffer, length) == 0) {
			// Something went wrong on transmitting data
			error = true;
		}
	}
	memset(buffer, '\0', sizeof(buffer));
}

/*
 * Function: testComponents
 * ----------------------------
 *   Inital test of the components
 *
 */

void testComponents(void) {
#if	REVISION == BASE_REV_1
// Show all LED color
	LED_setLED(COL_RED);
	RTC_delay_ms(250);
	LED_clearLED();
	LED_setLED(COL_GREEN);
	RTC_delay_ms(250);
	LED_clearLED();
	LED_setLED(COL_BLUE);
	RTC_delay_ms(250);
	LED_clearLED();
#elif	REVISION == BASE_REV_2
// Show all LED color
	LED_setLED(COL_RED);
	RTC_delay_ms(250);
	LED_clearLED();
	LED_setLED(COL_GREEN);
	RTC_delay_ms(250);
	LED_clearLED();
#endif
}

//
void USART1_RX_IRQHandler(void) {
	if (USART1 ->STATUS & USART_STATUS_RXDATAV) {
		int i = 0;
		memset(UART_receive, '\0', sizeof(UART_receive));
		bool getData = false;
		uint8_t comLength = 0;
		UART_receive[i] = USART_Rx(USART1 );
		uint32_t rounds = 0;
		while (i < 256 && rounds < 140000) {
			rounds++;
			if (USART1 ->STATUS & USART_STATUS_RXDATAV) {
				i++;
				UART_receive[i] = USART_Rx(USART1 );       // store the data
				if (i < 11 && !getData
						&& memcmp(UART_receive, "transmit", 8) == 0) {
					getData = true;
				}
				if (getData && i > 10 && i < 18 && UART_receive[i] == ' ') {
					// Check if ID is in hex format
					if (memcmp(UART_receive, "transmit 0x", 11) == 0) {
						comLength = getIdLength((uint8_t*) UART_receive, 11)
								+ 11;
					} else { // ID is in decimal format
						char wakeupid[9] = { 0 };
						int pos = 0;
						while (pos < 8 && UART_receive[9 + pos] != ' ') {
							wakeupid[pos] = UART_receive[9 + pos];
							pos++;
						}
						comLength = getIdLength((uint8_t *) wakeupid, 0) + 9;
					}
				}
				if (getData && comLength != 0 && i > comLength
						&& i < comLength + 6 && UART_receive[i] == ' ') {
					uint8_t tmpLength[4] = { 0 };
					datLength = getIdLength((uint8_t *) UART_receive,
							comLength + 1);
					arraycpy(tmpLength, (uint8_t *) UART_receive, comLength + 1,
							datLength);
					comLength += datLength;
					datLength = atoi((char *) tmpLength);
				}

				if (getData) {
					// TODO: Check
					if (datLength != 0 && comLength != 0
							&& i >= comLength + 1 + datLength) {
						//uartLength = i + 1;
						//break;
						getData = false;
					}
				} else {
					if (UART_receive[i - 1] == '\r'
							&& UART_receive[i] == '\n') {
						uartLength = i + 1;
						break;
					}
				}
			}
			uartLength = 0;
			if (rounds == 140000) {
				uartError = true;
			}
		}
	}
	/* Clear RXDATAV interrupt */
	USART_IntClear(USART1, USART_IF_RXDATAV);
}
#endif

// Radio timeout timer
void TIMER1_IRQHandler(void) {
	__disable_irq();
	radio_handle_timeout(&xfer);
	TIMER_IntClear(TIMER1, TIMER_IF_OF);
	__enable_irq();
}

// CC1101 GDO0 Interrupt
void GPIO_EVEN_IRQHandler(void) {
	if (GPIO_IntGetEnabled() & (1 << CC1101_GDO0_PIN)) {
		radio_handle_transfer_end(&xfer);
		/* Clear interrupt flag. */
		GPIO_IntClear(1 << CC1101_GDO0_PIN);
	}
#if MODE == NORMAL
	if (GPIO_IntGetEnabled() & (1 << W5100IntPin)) {

		GPIO_IntClear(1 << W5100IntPin);
	}
#endif
}

// CC1101 GDO2 Interrupt
void GPIO_ODD_IRQHandler(void) {
	if (GPIO_IntGetEnabled() & (1 << CC1101_GDO2_PIN)) {
		radio_handle_transfer_threshold(&xfer);
		/* Clear interrupt flag. */
		GPIO_IntClear(1 << CC1101_GDO2_PIN);
	}
}

