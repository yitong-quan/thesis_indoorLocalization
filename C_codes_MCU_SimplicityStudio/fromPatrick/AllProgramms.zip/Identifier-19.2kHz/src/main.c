/**************************************************************************//**
 * @file
 * @brief Identifier
 * @author
 * @version
 ******************************************************************************/

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_rmu.h"
#include "em_gpio.h"
#include "em_leuart.h"

#include "HWinit.h"
#include "AS3933.h"
#include "ANTENNA.h"
#include "CC1101.h"
#include "RADIO.h"
#include "RADIO_CONFIG.h"
#include "RFPACKETHELPER.h"
#include "EEPROM_handler.h"
#include "WORKMODES.h"
#include "revisionDef.h"
#include "UART.h"
#include "DMA_LEUART.h"
#include "RTC.h"
#include "TIMER.h"
#include "CRC.h"
#include "MISC.h"
#include "TestModes.h"

/* SYSTEM VARIABLES */
struct radio_transfer xfer;  							// Radio Transfer Handler
#if UART_DEBUG
char UART_data[256] = { 0 }; 							// UART String Buffer
#endif
uint8_t CC1101_receive[256] = { 0 };					// CC1101 Receive Buffer
uint8_t CC1101_send[256] = { 0 };						// CC1101 Send Buffer
uint8_t CC1101_data[256] = { 0 };						// CC1101 Data Buffer
uint8_t CC_length = 0;									// CC1101 Length Variable
uint8_t STATE_OPT_BYTE = 0x00;							// GETSTATE Option Byte
char UART_kbs_data[256] = { 0 }; 						// KBS UART String Buffer
uint16_t UART_kbs_length = 0x00;						// KBS UART data length
bool UART_kbs_busy_flag = false;						// BUSY FLAG for KBS UART DATA

/* GLOBAL VARIABLES */
uint32_t MY_IDENTIFIER_ID = IDENTIFIER_ID;				// Identifier ID
uint32_t MY_WAKEUP_ID = IDENTIFIER_ID;					// Same as Identifier ID
uint32_t TABLE_WAKEUP_ID = GENERAL_TABLE_WAKEUP_ID;		// Table WakeUp Address
uint32_t ID_WHO_WOKE_ME_UP = 0x00000000;				// ID of received WakeUp Signal
uint8_t OPTION_BYTE = 0x00;								// Option Byte in AS3933 (Normal mode, Data mode,...)
uint8_t AS_RSSI = 0;				 					// Received Signal Strength Indicator (dB)
int8_t CC_RSSI = 0;  									// Received Signal Strength Indicator (dBm)
uint16_t BAT_mV = 0;									// Battery Status of this node (mV)

/* AES VARIABLES */
uint8_t AES_decryption_key[16];  						// AES Decryption Key
uint8_t AES_encryption_key[] = AES_ENCRYPTION_KEY;		// AES Encryption Key 128 bit
uint8_t AES_decryption_public_key[16];  				// AES Decryption Public Key
uint8_t AES_encryption_public_key[] = AES_ENCRYPTION_PUBLIC_KEY;		// AES Encryption Public Key 128 bit
const uint8_t AES_initVector[] = AES_INIT_VECTOR;  		// Initialization vector used during CBC

/* PA table settings, see config.h */
uint8_t paTableWakeUp[8] 	= PA_TABLE_HIGH_POWER_REDUCED_IF;
uint8_t paTableDataProgrammer[8]   = PA_FSK_ULTRA_LOW;
uint8_t paBaseData[8] 		= PA_FSK;					// 0dBm
#if REDUCED_FSK_POWER
uint8_t paTableData[8]   	= PA_FSK_LOW;  				// 0dBm
#else
uint8_t paTableData[8]   	= PA_FSK;					// 12dBm
#endif

/* CSMA SETTINGS */
const uint16_t SLOT_SIZE = 25;							// Size of s single CSMA Time Slot in ms
const uint16_t MAX_NUM_OF_SENDS = 5;					// Maximum Number of repeating in case of failed transmissions
const uint16_t MAX_NUM_OF_SLOTS = 50;					// Maximum number of possible time slots
uint8_t MAX_NUM_OF_TRIES = 10;							// Maximum number of (successful but not acknowledged) tries to send data

/* TIMESLOT SETTINGS */
#if USE_CSMA_CA
	uint16_t RESPONSE_TIMEOUT = 75;						// Timeout when no more responses from tables
#else
	#define NUM_OF_TIMESLOTS  		10					// Max. number of responding table
	#define SEND_DURATION  			50					// Time needed to send out packet
	#define ACKTIME  				25					// Time needed for ACK from Identifier
	#define TABLE_MAX_NUM_OF_TRIES  3					// Maximum number of tries to send data from table to identifier
	#define OFFSET  				10					// Offset if time slot == 0
	uint16_t RESPONSE_TIMEOUT = ((NUM_OF_TIMESLOTS + 1) * ((SEND_DURATION + ACKTIME) * TABLE_MAX_NUM_OF_TRIES) + OFFSET);	// Size of time slot
#endif

/* INTERRUPT ROUTINES DECLARATION */
void TIMER1_IRQHandler(void);
void GPIO_EVEN_IRQHandler(void);
void GPIO_ODD_IRQHandler(void);
#if (REVISION == IDENTIFIER_REV_3) && BROADCASTS_ENABLED
void LEUART0_IRQHandler(void);
#endif

/**************************************************************************//**
 * @brief  Main function
 *****************************************************************************/
int main(void) {
	/* Chip errata */
	CHIP_Init();

	/* Initialize HW (SPI, UART, GPIO, CLOCKS, ...) */
	enter_DefaultMode_from_RESET();

	/* Initialize RTC for Timing Purposes */
	RTC_init(1000);

	/* Initialize Timer 0 for milliseconds */
	TIMER_init(TIMER0, cmuClock_TIMER0, TIMER0_IRQn);

	// Initialize Timer 2 for microseconds
	TIMER_init_us(TIMER2, cmuClock_TIMER2, TIMER2_IRQn);

	/* Switch off LEDs */
	LED_clearLED();

	/* Initial Switch antenna to CC1101 RF Module */
	ANTENNA_switch(ANTENNA_DEST_CC1101);

	/* Initialize CC1101 RF Module */
	cc1101_spi_init(CC1101_SPI_BAUDRATE);
	cc1101_change_config_to(CC1101_WAKEUP_CONFIG_NARROW_BAND, paTableWakeUp);
	NVIC_EnableIRQ(GPIO_EVEN_IRQn);
	NVIC_EnableIRQ(GPIO_ODD_IRQn);
	radio_init(&xfer, TIMER1, cmuClock_TIMER1, TIMER1_IRQn);

	/* Initialize Watchdog */
	#if WDOG_ENABLED && (MODE == NORMAL || MODE == TEST_WATCHDOG_FUNCTION)
		if (RMU_ResetCauseGet() & RMU_RSTCAUSE_WDOGRST) {
			// Something went wrong -> WDOG triggered
			#if UART_DEBUG
			UART_WriteString("ERROR: WDOG triggered!!\r\n", sizeof("ERROR: WDOG triggered!!\r\n"));
			#endif
		}

		// (Re-)initialize WDOG
		RMU_ResetCauseClear();
		WDOG_enter_DefaultMode_from_RESET();
		WDOG_Feed();
	#endif

	/* Initialize EEPROM */
	#if USE_EEPROM_VALUES
		EEPROM_init();
		if (EEPROM_OVERWRITE_VALUES_ON_START) {
			EEPROM_write(&MY_IDENTIFIER_ID, &MY_WAKEUP_ID, AES_encryption_key);
		}
		EEPROM_read_and_store_into(&MY_IDENTIFIER_ID, &MY_WAKEUP_ID, AES_encryption_key);
	#endif

	/* Calculate (once) decryption key from the original key */
	AES_DecryptKey128(AES_decryption_key, AES_encryption_key);
	AES_DecryptKey128(AES_decryption_public_key, AES_encryption_public_key);

	// Enable KBS UART LISTENING
	#if REVISION == IDENTIFIER_REV_3 && KBS_UART_ENABLED
		// Enable USART1
		USART1 ->ROUTE |= USART_ROUTE_RXPEN | USART_ROUTE_TXPEN;
		// Enable KBS Attention Signal Interrupt
		UART_kbs_wake_enable(true);
	#endif

	/* Optional test modes, to set in config.h */
	#if MODE != NORMAL
	TESTMODE_enter(&xfer);
	#endif

	/* Infinite loop */
	while (1) {

		#if UART_DEBUG
		BAT_mV = UART_kbs_get_bat_voltage();
		sprintf(UART_data,
				"Identifier:\r\nIdentifier_ID: 0x%X WakeUp_ID: 0x%X BAT: %dmV\r\n",
				(int) MY_IDENTIFIER_ID, (int) MY_IDENTIFIER_ID, (int) BAT_mV);
		UART_WriteString(UART_data, sizeof(UART_data));
		memset(UART_data, '\0', sizeof(UART_data));
		#endif

		// Blink LED
		LED_setLED(COL_RED);
		RTC_delay_ms(10);
		LED_clearLED();

		// Feed Watchdog
		#if WDOG_ENABLED
			WDOG_Feed();
		#endif

		/*
		 * Go into Sleep Mode and enable AS3933 WakeUp
		 */

		// Power Down CC1101
		cc1101_spi_init(CC1101_SPI_BAUDRATE);
		cc1101_power_down();

		// Device is not busy at present
		UART_kbs_busy_flag = false;

		// Enable AS3933 WakeUp by Address
		#if		WU_ADDR_LENGTH == USE_8_BIT
			AS3933_enable_wakeup_by_8bit_address(MY_WAKEUP_ID, AS3933_SPI_BAUDRATE);
		#elif	WU_ADDR_LENGTH == USE_16_BIT
			AS3933_enable_wakeup_by_16bit_address(MY_WAKEUP_ID, AS3933_SPI_BAUDRATE);
		#elif	WU_ADDR_LENGTH == USE_24_BIT
			AS3933_enable_wakeup_by_24bit_address(MY_WAKEUP_ID, AS3933_SPI_BAUDRATE);
		#endif

		// Enable LEUART for broadcasts
		#if REVISION == IDENTIFIER_REV_3 && BROADCASTS_ENABLED
			LEUART0_enter_DefaultMode_from_RESET();
			DMA_setup_leuart();
		#endif

		// Switch antenna to WakeUp Receiver
		ANTENNA_switch(ANTENNA_DEST_WAKEUPRF);
		// Clear Broadcast Pattern
		BROADCAST_PATTERN = 0x00;

		// Now enter SleepMode!!
		while (!WAKEUP_received && !BROADCAST_PATTERN) {
			__disable_irq();
			#if REVISION == IDENTIFIER_REV_3 && BROADCASTS_ENABLED
				EMU_EnterEM2(true);  // Broadcasts need EM2 for LEUART listening
			#else
				EMU_EnterEM3(true);  // EM3
			#endif
			__enable_irq();
		}

		/*
		 * AWAKE!
		 */

		// Check if WakeUp was a broadcast
		#if REVISION == IDENTIFIER_REV_3 && BROADCASTS_ENABLED
			if (BROADCAST_PATTERN) {
				// Time Slot for CSMA
				RTC_start(100);

				// Build Broadcast Packet
				MODE_broadcast_mode(CC1101_send, &CC_length, BROADCAST_PATTERN, MY_IDENTIFIER_ID, GENERAL_BROADCAST_BASE_ADDR, MY_WAKEUP_ID, AES_encryption_public_key, AES_initVector);

				// Device is busy now
				UART_kbs_busy_flag = true;

				// Send Data to Base
				if (CC_length > 0) {
					// Switch antenna to CC1101 RF module and reconfigure SPI
					ANTENNA_switch(ANTENNA_DEST_CC1101);
					cc1101_spi_init(CC1101_SPI_BAUDRATE);
					uint8_t num_of_slot = 0, num_of_sends = 0;
					while(num_of_slot < MAX_NUM_OF_SLOTS && num_of_sends < MAX_NUM_OF_SENDS) {
						// Set CC1101 RF Module to Data Communication Configuration
						if (BROADCAST_PATTERN == BROADCAST_SERVICE_SETTINGS) {
							cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableDataProgrammer);
						} else {
							cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
						}
						// Wait for next time slot to be opened and try again
						while(!RTC_TIMEOUT);
						// Compute next time slot
						RTC_start(SLOT_SIZE);
						// Wait a random time (up to 4 ms)
						uint16_t random_delay = ((rand() * MY_IDENTIFIER_ID / AS_RSSI + BAT_mV) % 16) * 250;
						TIMER_delay_us(TIMER2, random_delay);
						// Send if channel is free
						bool TX_OK = radio_send_packet_use_CSMA_CA(&xfer, CC1101_send, CC_length);
						// if channel was free (TX_OK), check for ACK
						if (TX_OK) {
							// Set CC1101 RF Module to Data Communication Configuration
							if (BROADCAST_PATTERN == BROADCAST_SERVICE_SETTINGS) {
								cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableDataProgrammer);
							} else {
								cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
							}
							// Check if Base ACK my packet
							uint16_t listen_time = (SLOT_SIZE - 12 - (random_delay/1000));
							uint32_t SourceAddr = GENERAL_BROADCAST_BASE_ADDR;
							bool acknowledged = cc1101_check_ack(&xfer,	&SourceAddr, &MY_IDENTIFIER_ID, AES_decryption_public_key, AES_initVector, listen_time);

							if (acknowledged) {  // ACK!
								#if UART_DEBUG
								UART_WriteString("BASE ACK!\r\n\r\n", sizeof("BASE ACK!\r\n\r\n"));
								#endif
								break; // ACK! -> leave while
							}

							num_of_sends++;
							#if UART_DEBUG
							sprintf(UART_data, "BASE NOT ACK! RandomDelay: %dus \r\n", random_delay);
							UART_WriteString(UART_data, sizeof(UART_data));
							memset(UART_data, '\0', sizeof(UART_data));
							#endif
						}
						num_of_slot++;
					}
				}
				continue;
			}
		#endif

		/*
		 * Normal WakeUp -> Read AS3933 data
		 */
		ID_WHO_WOKE_ME_UP = 0x00;
		OPTION_BYTE = 0x00;
		UART_kbs_busy_flag = true;
		if (!AS3933_receive_data(&ID_WHO_WOKE_ME_UP, &AS_RSSI, &OPTION_BYTE, AS3933_SPI_BAUDRATE)) {
			// WakeUp NOT addressed to me (Additional addr byte -> no match)
			#if UART_DEBUG
			UART_WriteString("WakeUp NOT addressed to me\r\n", sizeof("WakeUp NOT addressed to me\r\n"));
			#endif
			continue;  // Go back to sleep!
		}
		UART_kbs_busy_flag = false;

		// Disable LEUART for broadcast listening
		#if REVISION == IDENTIFIER_REV_3 && BROADCASTS_ENABLED
			LEUART_Enable(LEUART0, leuartDisable);
		#endif

		/*
		 * ACK to Base Station!
		 */
		// Switch antenna to CC1101 RF module and reconfigure SPI
		ANTENNA_switch(ANTENNA_DEST_CC1101);
		cc1101_spi_init(CC1101_SPI_BAUDRATE);

		/*
		 * React on AS_OPTION_BYTE
		 */
		// BASE CMD: transmit
		if (OPTION_BYTE == AS_OPT_BYTE_DATA_MODE) {

			UART_kbs_busy_flag = true;

			// ACK WakeUp
			cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
			cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_key, AES_initVector);

			// Listen for Data
			uint8_t dat_length = 0x00;
			RTC_start(400);
			while (!dat_length && !RTC_TIMEOUT) {
				// Receive Data
				memset(CC1101_receive, 0x00, sizeof(CC1101_receive));
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
				radio_receive_packet(&xfer, CC1101_receive, &CC_length, 410);

				// Decrypt received packet (AES128CBC)
				RFPacket_decrypt_AES128CBC(CC1101_receive, AES_decryption_key, AES_initVector);

				// Check if received packet is valid
				uint8_t MSG_TYPE = CC_OPT_BYTE_DAT_BASIS_TO_IDENTIFIER;
				dat_length = RFPacket_check_and_remove_header(CC1101_receive, &ID_WHO_WOKE_ME_UP, &MY_IDENTIFIER_ID, &MSG_TYPE);
			}

			// If no (or wrong addressed) data received, go back to sleep
			if (dat_length == 0) continue;

			// Acknowledge reception of data
			cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
			cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_key, AES_initVector);

			UART_kbs_busy_flag = false;

			// React on received data -> transmit to KBS UART
			uint8_t ret = MODE_identifier_receiving_mode(CC1101_receive, dat_length);

			// Send UART STATUS to Base
			memset(CC1101_data, 0x00, sizeof(CC1101_data));
			CC_length = 3;
			switch (ret) {
			case UART_CMD_ACK:
				strcpy((char*) CC1101_data, "ACK");
				break;
			case UART_CMD_NUL:
				strcpy((char*) CC1101_data, "NUL");
				break;
			case UART_CMD_TOUT:
				strcpy((char*) CC1101_data, "TOUT");
				CC_length = 4;
				break;
			case UART_CMD_DLE:
				strcpy((char*) CC1101_data, "DLE");
				break;
			case UART_CMD_NAK: // default
			default:
				strcpy((char*) CC1101_data, "NAK");
				break;
			}

			// Build Header
			RFPacket_build_header(CC1101_send, CC1101_data, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, CC_OPT_BYTE_MSG_IDENTIFIER_TO_BASIS, &CC_length);
			// Add length byte for CC1101
			RFPacket_add_cc_length(CC1101_send, &CC_length);
			// Encrypt send packet (AES128CBC)
			RFPacket_encrypt_AES128CBC(CC1101_send, &CC_length, AES_encryption_key, AES_initVector);

			UART_kbs_busy_flag = true;

			// Send Data to Base
			uint8_t i = 0;
			while (i < MAX_NUM_OF_TRIES) {
				bool ENTERED_TX_STATE;
				uint16_t random_delay = ((rand() * MY_IDENTIFIER_ID / AS_RSSI + BAT_mV) % 16) * 250;
				TIMER_delay_us(TIMER2, random_delay);
				#if USE_CSMA_CA
					cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
					ENTERED_TX_STATE = radio_send_packet_use_CSMA_CA(&xfer, CC1101_send, CC_length);
				#else
					cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
					radio_send_packet(&xfer, CC1101_send, CC_length);
					ENTERED_TX_STATE = true;
				#endif

				if (ENTERED_TX_STATE) {
					// Check if Identifier ACK my packet
					cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
					bool acknowledged = cc1101_check_ack(&xfer, &ID_WHO_WOKE_ME_UP, &MY_IDENTIFIER_ID, AES_decryption_key, AES_initVector, 75);
					if (acknowledged) {  // ACK!
						#if UART_DEBUG
						UART_WriteString("BASE-STATION ACK!\r\n\r\n", sizeof("BASE-STATION ACK!\r\n\r\n"));
						#endif
						break; // ACK! -> leave for
					}
					i++;
				}
			}

			// Device is not busy anymore
			UART_kbs_busy_flag = false;

			// If UART Status was DLE, try to send packet again
			if (ret == UART_CMD_DLE) {
				// Try to send UART data 3 times with 500ms delay
				while (ret != UART_CMD_ACK && i < 3) {
					RTC_delay_ms(500);
					ret = UART_kbs_transmit((char) CC1101_receive[0], (char*) CC1101_receive, dat_length);
				}

				// If UART ACK -> set DLE SUCCESS in GETSTATE OPT BYTE
				if (ret == UART_CMD_ACK) {
					STATE_OPT_BYTE |= STATE_OPT_BYTE_DLE_SUCCESS;
				}
			}

			continue; // Go back to sleep and listen mode

		// BASE CMD: getState
		} else if (OPTION_BYTE == AS_OPT_BYTE_STATUS_MODE) {

			// ACK WakeUp
			UART_kbs_busy_flag = true;
			cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
			cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_key, AES_initVector);
			UART_kbs_busy_flag = false;

			// Send out Status to Base Station
			memset(CC1101_send, 0x00, sizeof(CC1101_send));
			MODE_identifier_status_mode(CC1101_send, &CC_length, UART_kbs_data, &UART_kbs_length, STATE_OPT_BYTE, AS_RSSI, MY_IDENTIFIER_ID, ID_WHO_WOKE_ME_UP, AES_encryption_key, AES_initVector);

			UART_kbs_busy_flag = true;

			// Send Data to Base
			uint8_t i = 0;
			while (i < MAX_NUM_OF_TRIES) {
				bool ENTERED_TX_STATE;
				uint16_t random_delay = ((rand() * MY_IDENTIFIER_ID / AS_RSSI + BAT_mV) % 16) * 250;
				TIMER_delay_us(TIMER2, random_delay);
				#if USE_CSMA_CA
					ENTERED_TX_STATE = radio_send_packet_use_CSMA_CA(&xfer, CC1101_send, CC_length);
				#else
					radio_send_packet(&xfer, CC1101_send, CC_length);
					ENTERED_TX_STATE = true;
				#endif

				if (ENTERED_TX_STATE) {
					// Check if Base ACK my packet
					cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
					bool acknowledged = cc1101_check_ack(&xfer, &ID_WHO_WOKE_ME_UP, &MY_IDENTIFIER_ID, AES_decryption_key, AES_initVector, 75);
					if (acknowledged) {  // ACK!
						#if UART_DEBUG
						UART_WriteString("BASE-STATION ACK!\r\n\r\n", sizeof("BASE-STATION ACK!\r\n\r\n"));
						#endif
						break; // ACK! -> leave for
					}
					i++;
				}
			}
			// Clear UART_DATA buffer after send, because Base successfully pulled data
			memset(UART_kbs_data, 0x00, sizeof(UART_kbs_data));
			UART_kbs_length = 0;
			STATE_OPT_BYTE = 0x00;

			continue; // Go back to sleep and listen mode

		// BASE CMD: initialize
		} else if (OPTION_BYTE == AS_OPT_BYTE_SERVICE_MODE) {

			// ACK WakeUp
			UART_kbs_busy_flag = true;
			cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableDataProgrammer);
			cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_public_key, AES_initVector);

			// Listen for Data
			uint8_t dat_length = 0x00;
			RTC_start(400);
			while (!dat_length && !RTC_TIMEOUT) {
				// Receive Data
				memset(CC1101_receive, 0x00, sizeof(CC1101_receive));
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableDataProgrammer);
				radio_receive_packet(&xfer, CC1101_receive, &CC_length, 410);

				// Decrypt received packet (AES128CBC)
				RFPacket_decrypt_AES128CBC(CC1101_receive, AES_decryption_public_key, AES_initVector);

				// Check if received packet is valid
				uint8_t MSG_TYPE = CC_OPT_BYTE_MSG_SERVICE;
				dat_length = RFPacket_check_and_remove_header(CC1101_receive, &ID_WHO_WOKE_ME_UP, &MY_IDENTIFIER_ID, &MSG_TYPE);
			}

			// If no data received, go back to sleep
			if (dat_length != 30) continue;

			// Acknowledge reception of data from table
			cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableDataProgrammer);
			cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_public_key, AES_initVector);

			UART_kbs_busy_flag = false;

			// React on received data
			if (MODE_service_mode(CC1101_receive)) {
				// Overwrite new Settings (ID, WU_ID, AES)
				EEPROM_read_and_store_into(&MY_IDENTIFIER_ID, &MY_WAKEUP_ID, AES_encryption_key);
				AES_DecryptKey128(AES_decryption_key, AES_encryption_key);
				// ACK to Base
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableDataProgrammer);
				cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_key, AES_initVector);
			}

			continue; // Go back to sleep and listen mode
		}

		// Make sure, that WU was with normal mode
		if (OPTION_BYTE != AS_OPT_BYTE_NORMAL_MODE) {
			continue; // Go back to sleep and listen mode
		}

		/*
		 * BASE CMD: find
		 */

		// ACK WakeUp
		UART_kbs_busy_flag = true;
		cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
		cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, AES_encryption_key, AES_initVector);
		UART_kbs_busy_flag = false;

		#if UART_DEBUG
		sprintf(UART_data,
				"Awake!\r\nAS-RSSI: %ddB OPTIONS: 0x%X Woke up by BasisID: 0x%X \r\n",
				AS_RSSI, OPTION_BYTE, (int) ID_WHO_WOKE_ME_UP);
		UART_WriteString(UART_data, sizeof(UART_data));
		memset(UART_data, '\0', sizeof(UART_data));
		#endif

		/*
		 * Wake up surrounding tables
		 */

		// (Prepare variables)
		memset(CC1101_data, 0x00, sizeof(CC1101_data));
		memset(CC1101_send, 0x00, sizeof(CC1101_send));
		uint8_t known_tables[256] = { 0 };
		uint8_t known_tables_idx = 0, num_of_responses = 0, idx = 4, i = 0, table_high = 0, table_mid = 0, table_low = 0, iterations = 0;
		bool table_already_known = false;
		UART_kbs_busy_flag = true;

		for (iterations = 0; iterations < NUM_OF_WAKEUP_ITERATIONS; iterations++) {
			// Set CC1101 RF Module to WakeUp Configuration
			cc1101_change_config_to(CC1101_WAKEUP_CONFIG_NARROW_BAND, paTableWakeUp);

			// Send WakeUp Packet (Tables)
			#if		WU_ADDR_LENGTH == USE_8_BIT
				cc1101_send_wakeup_packet_8bit_addr(&xfer, TABLE_WAKEUP_ID, MY_IDENTIFIER_ID, AS_OPT_BYTE_NORMAL_MODE);
			#elif	WU_ADDR_LENGTH == USE_16_BIT
				cc1101_send_wakeup_packet_16bit_addr(&xfer, TABLE_WAKEUP_ID, MY_IDENTIFIER_ID, AS_OPT_BYTE_NORMAL_MODE);
			#elif	WU_ADDR_LENGTH == USE_24_BIT
				cc1101_send_wakeup_packet_24bit_addr(&xfer, TABLE_WAKEUP_ID, MY_IDENTIFIER_ID, AS_OPT_BYTE_NORMAL_MODE);
			#endif

			/*
			 * Listen for responses of tables and build send packet
			 */

			// Compute max listen Time
			RTC_start(RESPONSE_TIMEOUT);
			while (!RTC_TIMEOUT && num_of_responses < 34) {

				// Receive Data from Tables
				memset(CC1101_receive, 0x00, sizeof(CC1101_receive));
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
				radio_receive_packet(&xfer, CC1101_receive, &CC_length, RESPONSE_TIMEOUT);

				// Decrypt received packet (AES128CBC)
				RFPacket_decrypt_AES128CBC(CC1101_receive, AES_decryption_key, AES_initVector);

				// Check packet and remove header
				uint8_t MSG_TYPE = CC_OPT_BYTE_MSG_TABLE_TO_IDENTIFIER;
				uint32_t TABLE_ADDR = 0x00;
				uint8_t dat_length = RFPacket_check_and_remove_header(CC1101_receive, &TABLE_ADDR, &MY_IDENTIFIER_ID, &MSG_TYPE);

				// Check if Data received
				if (dat_length == 0) {
					continue;
				}

				// Valid Data Received
				RTC_start(RESPONSE_TIMEOUT);  // Reset RTC Timeout after each received table

				// Read/ Prepare DATA
				table_high = (TABLE_ADDR >> 16);
				table_mid = (TABLE_ADDR >> 8);
				table_low = (TABLE_ADDR);
				int8_t TABLE_CC_RSSI = cc1101_read_rssi();
				uint8_t TABLE_AS_RSSI = CC1101_receive[0];
				uint16_t TABLE_BAT_VOLTAGE = (((uint16_t) CC1101_receive[1]) << 8 | CC1101_receive[2]);

				// Acknowledge reception of data from table
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paTableData);
				cc1101_ack_reception(&xfer, &MY_IDENTIFIER_ID, &TABLE_ADDR, AES_encryption_key, AES_initVector);

				// Check if table has already sent data
				table_already_known = false;
				i = 0;
				while (!table_already_known && i <= known_tables_idx) {
					// Search index of Table
					if (!(known_tables[i] == table_high && known_tables[i+1] == table_mid && known_tables[i+2] == table_low)) {
						i++;
						continue;
					}

					// Table found in list
					table_already_known = true;

					// Search already found Tables in data array
					bool found = false;
					i = 0;
					while (!found && i < 256) {
						i++;
						if(!(CC1101_data[i] == table_high && CC1101_data[i+1] == table_mid && CC1101_data[i+2] == table_low)) {
							continue;
						}

						// Table found in list
						found = true;

						// Overwrite with the best RSSI values
						if (TABLE_AS_RSSI > CC1101_data[i+3]) {
							CC1101_data[i+3] = TABLE_AS_RSSI;
						}
						if (TABLE_CC_RSSI > (int8_t) CC1101_data[i+4]) {
							CC1101_data[i+4] = TABLE_CC_RSSI;
						}

						break;  // Data overwritten, break
					}
					// Table has already sent data, so we can break
					break;
				}

				// Store the received data
				if (!table_already_known) {
					// Add table to known tables list
					known_tables[known_tables_idx++] = table_high;
					known_tables[known_tables_idx++] = table_mid;
					known_tables[known_tables_idx++] = table_low;

					// Increase Number of Responses
					num_of_responses++;

					// Add received Data to send packet
					CC1101_data[idx++] = table_high; 					// TABLE_ID (high)
					CC1101_data[idx++] = table_mid; 					// TABLE_ID (middle)
					CC1101_data[idx++] = table_low; 					// TABLE_ID (low)
					CC1101_data[idx++] = TABLE_AS_RSSI; 				// AS3933 RSSI OF TABLE_ID
					CC1101_data[idx++] = TABLE_CC_RSSI; 				// CC1101 RSSI (signed int!!)
					CC1101_data[idx++] = (TABLE_BAT_VOLTAGE >> 8); 		// BAT VOLTAGE OF TABLE_ID
					CC1101_data[idx++] = (TABLE_BAT_VOLTAGE & 0xFF); 	// BAT VOLTAGE OF TABLE_ID
				}
			}
		}

		UART_kbs_busy_flag = false;

		// Complete the send packet
		BAT_mV = UART_kbs_get_bat_voltage();
		CC1101_data[0] = num_of_responses;
		CC1101_data[1] = AS_RSSI;
		CC1101_data[2] = BAT_mV >> 8;
		CC1101_data[3] = BAT_mV & 0xFF;

		// Build Header
		RFPacket_build_header(CC1101_send, CC1101_data, &MY_IDENTIFIER_ID, &ID_WHO_WOKE_ME_UP, CC_OPT_BYTE_MSG_IDENTIFIER_TO_BASIS, &idx);

		// Add length byte for CC1101
		RFPacket_add_cc_length(CC1101_send, &idx);

		// Encrypt send packet (AES128CBC)
		RFPacket_encrypt_AES128CBC(CC1101_send, &idx, AES_encryption_key, AES_initVector);

		#if UART_DEBUG
		sprintf(UART_data, "Responses: %d \r\n", num_of_responses);
		UART_WriteString(UART_data, sizeof(UART_data));
		memset(UART_data, '\0', sizeof(UART_data));
		#endif

		/*
		 * Send Data to Basis Station
		 */

		UART_kbs_busy_flag = true;
		uint8_t num_of_tries = 0;
		while (num_of_tries < MAX_NUM_OF_TRIES) {
			// Send Data to Basis Station
			#if USE_CSMA_CA
				RTC_start(50);
				// Wait a random time
				uint16_t random_delay = ((rand() * MY_IDENTIFIER_ID / AS_RSSI + BAT_mV) % 16) * 250;
				TIMER_delay_us(TIMER2, random_delay);
				// Send out packet if channel is free
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
				if (radio_send_packet_use_CSMA_CA(&xfer, CC1101_send, idx)) {
					// Check if Base ACK my packet
					cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
					bool acknowledged = cc1101_check_ack(&xfer, &ID_WHO_WOKE_ME_UP, &MY_IDENTIFIER_ID, AES_decryption_key, AES_initVector, 75);

					if (acknowledged) {  // ACK!
						#if UART_DEBUG
						UART_WriteString("BASE-STATION ACK!\r\n\r\n", sizeof("BASE-STATION ACK!\r\n\r\n"));
						#endif
						break; // ACK! -> leave while
					}
					num_of_tries++;
				}
				while(!RTC_TIMEOUT);
			#else
				// Send out packet
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
				radio_send_packet(&xfer, CC1101_send, idx);
				// Check if Base ACK my packet
				cc1101_change_config_to(CC1101_DATA_38kBaud_CONFIG, paBaseData);
				bool acknowledged = cc1101_check_ack(&xfer, &ID_WHO_WOKE_ME_UP, &MY_IDENTIFIER_ID, AES_decryption_key, AES_initVector, 75);

				if (acknowledged) {  // ACK!
					#if UART_DEBUG
					UART_WriteString("BASE-STATION ACK!\r\n\r\n", sizeof("BASE-STATION ACK!\r\n\r\n"));
					#endif
					break; // ACK! -> leave while
				}

				#if UART_DEBUG
				UART_WriteString("BASE-STATION NOT ACK!\r\n", sizeof("BASE-STATION NOT ACK!\r\n"));
				#endif
				num_of_tries++;
			#endif
		}
	}
}


// Radio timeout timer
void TIMER1_IRQHandler(void) {
	__disable_irq();
	radio_handle_timeout(&xfer);
	TIMER_IntClear(TIMER1, TIMER_IF_OF);
	__enable_irq();
}

// CC1101 GDO0 Interrupt / AS3933 WakeUp Interrupt
void GPIO_EVEN_IRQHandler(void) {
	if (GPIO_IntGetEnabled() & (1 << CC1101_GDO0_PIN)) {
		radio_handle_transfer_end(&xfer);
		/* Clear interrupt flag. */
		GPIO_IntClear(1 << CC1101_GDO0_PIN);
	}
	#if 	REVISION == IDENTIFIER_REV_1 || REVISION == IDENTIFIER_REV_2
		if (WAKEUP_active) {
			if (GPIO_IntGetEnabled() & (1 << AS3933_WAKE_PIN)) {
				GPIO_IntDisable(1 << AS3933_WAKE_PIN);
				GPIO_IntClear(1 << AS3933_WAKE_PIN);
				WAKEUP_received = true;
			}
		}
	#endif
}

// CC1101 GDO2 Interrupt / AS3933 WakeUp Interrupt
void GPIO_ODD_IRQHandler(void) {
	if (GPIO_IntGetEnabled() & (1 << CC1101_GDO2_PIN)) {
		radio_handle_transfer_threshold(&xfer);
		/* Clear interrupt flag. */
		GPIO_IntClear(1 << CC1101_GDO2_PIN);
	}
	#if 	REVISION == IDENTIFIER_REV_3
		if (WAKEUP_active) {
			if (GPIO_IntGetEnabled() & (1 << AS3933_WAKE_PIN)) {
				GPIO_IntDisable(1 << AS3933_WAKE_PIN);
				GPIO_IntClear(1 << AS3933_WAKE_PIN);
				WAKEUP_received = true;
			}
		}

		#if (KBS_UART_ENABLED)
			if (GPIO_IntGetEnabled() & (1 << UART_WAKE_1_PIN)) {
				GPIO_IntDisable(1 << UART_WAKE_1_PIN);

				// Create temporary Buffer for local CMDs (getID or getBattery)
				char UART_kbs_data_tmp[256] = { 0 };
				int16_t UART_kbs_length_local = 0;

				#if KBS_BUSY_FLAG_1_ENABLED
				if (UART_kbs_busy_flag) {
					// WakeUp but device is busy at present! -> DLE
					USART_Tx(USART1, UART_CMD_DLE);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));
					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;
				}
				#endif

				// WakeUp -> Send ACK
				USART_Tx(USART1, UART_CMD_ACK);
				while (!(USART1 ->STATUS & USART_STATUS_TXC));

				// Listen for STX
				if (!UART_kbs_listen_for_byte(UART_CMD_STX, UART_KBS_STX_TIMEOUT)) {
					// No Data received -> NUL
					USART_Tx(USART1, UART_CMD_NUL);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));
					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;;
				}

				// Listen for Data
				UART_kbs_length_local = UART_kbs_listen_for_data(UART_kbs_data_tmp, UART_KBS_DATA_TIMEOUT);

				// ERR handling
				if (UART_kbs_length_local == UART_ERR_NUL) {
					// No Data received -> NUL
					USART_Tx(USART1, UART_CMD_NUL);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));
					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;
				} else if (UART_kbs_length_local == UART_ERR_NAK) {
					// CRC failed -> NAK
					USART_Tx(USART1, UART_CMD_NAK);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));
					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;
				}

				// React on local CMDs
				if (memcmp(UART_kbs_data_tmp, "Y", 1) == 0) {
					// Everything OK Complete Received Packet -> ACK
					USART_Tx(USART1, UART_CMD_ACK);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));

					// TODO: Maybe insert short delay (2ms)

					// Send/ Return IDENTIFIER ID
					char hex_ascii[7] = { 0 };
					sprintf(hex_ascii, "y%X", (int) MY_IDENTIFIER_ID);
					UART_kbs_transmit(hex_ascii[0], hex_ascii, sizeof(hex_ascii));
					memset(UART_kbs_data_tmp, '\0', sizeof(UART_kbs_data_tmp));
					UART_kbs_length_local = 0;

					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;
				} else if (memcmp(UART_kbs_data_tmp, "x", 1) == 0 && UART_kbs_length_local == 5) {
					// Convert received Data to integer
					char dec_ascii[4] = { 0 };
					uint8_t i;
					for (i = 0; i < 4; i++) {
						dec_ascii[i] = UART_kbs_data_tmp[1 + i];
					}
					UART_kbs_bat_voltage = atoi(dec_ascii);
					memset(UART_kbs_data_tmp, '\0', sizeof(UART_kbs_data_tmp));
					UART_kbs_length_local = 0;

					// Everything OK -> ACK
					USART_Tx(USART1, UART_CMD_ACK);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));
					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;
				}

				#if KBS_BUSY_FLAG_2_ENABLED
				// DLE when Buffer not pulled yet
				if (UART_kbs_length) {
					// UART Buffer not pulled yet -> DLE
					USART_Tx(USART1, UART_CMD_DLE);
					while (!(USART1 ->STATUS & USART_STATUS_TXC));
					// Return from Interrupt
					GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
					GPIO_IntClear(1 << UART_WAKE_1_PIN);
					return;
				}
				#endif

				// Everything OK -> ACK
				USART_Tx(USART1, UART_CMD_ACK);
				while (!(USART1 ->STATUS & USART_STATUS_TXC));

				// No temporary Data -> Copy Data in global Buffer
				memset(UART_kbs_data, 0x00, sizeof(UART_kbs_data));
				uint16_t i;
				for (i = 0; i < UART_kbs_length_local; i++) {
					UART_kbs_data[i] = UART_kbs_data_tmp[i];
				}
				UART_kbs_length = UART_kbs_length_local;

				// Poll UART DATA with AS_OPT_BYTE_STATUS (getState CMD)

				GPIO_IntConfig(UART_WAKE_1_PORT, UART_WAKE_1_PIN, false, true, true);
				GPIO_IntClear(1 << UART_WAKE_1_PIN);
			}
		#endif
	#endif
}

#if (REVISION == IDENTIFIER_REV_3) && BROADCASTS_ENABLED

// LEUART Signal Frame Interrupt
void LEUART0_IRQHandler(void) {
	/* Store and reset pending interrupts */
	leuartif = LEUART_IntGet(LEUART0 );
	LEUART_IntClear(LEUART0, leuartif);

	/* Signal frame found. */
	if (leuartif & LEUART_IF_SIGF) {
		/* Zero-terminate RX buffer */
		DMA_len = BUF_MAX - 1 - ((dmaControlBlock->CTRL >> 4) & 0x3FF);
		DMA_LEUART_RX_BUF[DMA_len - 1] = 0;

		/* Reactivate DMA */
		DMA_ActivateBasic(DMA_CHANNEL, /* Activate DMA channel 0 */
		true, /* Activate using primary descriptor */
		false, /* No DMA burst */
		NULL, /* Keep source */
		NULL, /* Keep destination */
		BUF_MAX - 1); /* Number of DMA transfer elements (minus 1) */

		// Last Byte in Buffer was '\r' (=13 dec), Preamble is '\220' (=144 dec), broadcast pattern is in between
		if (DMA_LEUART_RX_BUF[DMA_len-3] == '\220') {
			BROADCAST_PATTERN = DMA_LEUART_RX_BUF[DMA_len-2];
		}
	}
}

#endif
